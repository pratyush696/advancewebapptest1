import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min'; // Import Bootstrap JavaScript
import { MDBCol, MDBContainer, MDBFooter, MDBIcon, MDBRow } from 'mdb-react-ui-kit';
import React from 'react';
import './About.css';
import testimonialImage1 from './images/person1.jpg'; // Replace with your image paths
import testimonialImage2 from './images/person2.jpg'; // Replace with your image paths
import hero from './images/surpy.jpg'; // Replace with the correct image path

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="hero-section bg-white py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-6">
              <h1 className="display-4 text-danger">About Our Bank</h1>
              <p className="lead text-dark">
                At Scotiabank, we are committed to providing excellent banking services to help you achieve your financial goals. With a wide range of products and services, we strive to deliver exceptional value and support.
              </p>
              <a href="#" className="btn btn-danger btn-lg">Learn More</a>
            </div>
            <div className="col-md-6 text-center">
              <img 
                src={hero} 
                alt="Hero" 
                className="img-fluid rounded-circle" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials py-5">
        <div className="container">
          <h2 className="text-center mb-4">What Our Clients Say</h2>
          <div className="row">
            <div className="col-md-6 d-flex align-items-center">
              <div className="testimonial-image-container">
                <img 
                  src={testimonialImage1} 
                  alt="Client 1" 
                  className="img-fluid rounded-circle" 
                />
              </div>
              <div className="testimonial-image-container">
                <img 
                  src={testimonialImage2} 
                  alt="Client 2" 
                  className="img-fluid rounded-circle" 
                />
              </div>
            </div>
            <div className="col-md-6">
              <p className="lead text-dark">
                "Scotiabank has been a fantastic partner for my financial needs. Their customer service is exceptional, and their range of products is impressive. I highly recommend them!"
              </p>
              <p className="lead text-dark">
                "I've been a client for years, and I am continually impressed with the level of service and support I receive. Their team truly goes above and beyond to ensure customer satisfaction."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <MDBFooter bgColor='light' className='text-center text-lg-start text-muted'>
        <section className='d-flex justify-content-center justify-content-lg-between p-4 border-bottom'>
          <div className='me-5 d-none d-lg-block'>
            <span>Get connected with us on social networks:</span>
          </div>
          <div>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='facebook-f' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='twitter' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='google' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='instagram' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='linkedin' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='github' />
            </a>
          </div>
        </section>

        <section className=''>
          <MDBContainer className='text-center text-md-start mt-5'>
            <MDBRow className='mt-3'>
              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='gem' className='me-3' />
                  Scotiabank
                </h6>
                <p>
                  Have a question? Don't hesitate to call us!!!!
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='info-circle' className='me-3' />
                  About Us
                </h6>
                <p>
                  Learn more about our services and values.
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='address-book' className='me-3' />
                  Contact
                </h6>
                <p>
                  1234 Street Name, City, State, Country
                </p>
                <p>
                  Email: info@scotiabank.com
                </p>
                <p>
                  Phone: (123) 456-7890
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='cogs' className='me-3' />
                  Services
                </h6>
                <p>
                  <a href="#!" className='text-reset'>GIC Options</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Investment Planning</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Customer Support</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Online Banking</a>
                </p>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </section>

        <section className='p-4'>
          <MDBContainer>
            <p className='text-center mb-0'>
              © 2024 Scotiabank. All rights reserved.
            </p>
          </MDBContainer>
        </section>
      </MDBFooter>
    </div>
  );
}

export default Home;
