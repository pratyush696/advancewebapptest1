// src/BankingSystem.js
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // For navigation
import "./BankingSystem.css"; // Import the CSS file

function BankingSystem() {
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(0);
  const [showForm, setShowForm] = useState("deposit");
  const [transferAccountNumber, setTransferAccountNumber] = useState("");
  const [transferEmail, setTransferEmail] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferQuestion, setTransferQuestion] = useState("");
  const [transferAnswer, setTransferAnswer] = useState("");
  const [transferMessage, setTransferMessage] = useState("");

  const navigate = useNavigate(); // Initialize navigation

  const handleDeposit = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0) {
      setBalance(balance + amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: "Deposit",
        balanceAfter: balance + amt,
      };
      setTransactions([...transactions, newTransaction]);
      setAmount("");
      setAccountNumber("");
    }
  };

  const handleWithdraw = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0 && amt <= balance) {
      setBalance(balance - amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: "Withdraw",
        balanceAfter: balance - amt,
      };
      setTransactions([...transactions, newTransaction]);
      setAmount("");
      setAccountNumber("");
    }
  };

  const handleTransfer = () => {
    const amt = parseFloat(transferAmount);
    if (!isNaN(amt) && amt > 0 && amt <= balance) {
      setBalance(balance - amt);
      const newTransaction = {
        accountNumber: transferAccountNumber,
        amount: -amt, // Show as negative amount
        type: "eTransfer",
        balanceAfter: "N/A",
      };
      setTransactions([...transactions, newTransaction]);
      setTransferAccountNumber("");
      setTransferEmail("");
      setTransferAmount("");
      setTransferQuestion("");
      setTransferAnswer("");
      setTransferMessage("Money has been successfully deposited into the account.");
    } else {
      setTransferMessage("Invalid transfer details or insufficient funds.");
    }
  };

  const handleCancel = () => {
    navigate("/"); // Navigate to the home page
  };

  return (
    <div className="banking-background">
      <div className="container">
        <h1 className="text-center mt-5 mb-4">Transaction System</h1>
        <div className="d-flex justify-content-center mb-4">
          <button
            className={`btn ${showForm === "deposit" ? "btn-primary" : "btn-secondary"} mx-2`}
            onClick={() => setShowForm("deposit")}
          >
            Deposit
          </button>
          <button
            className={`btn ${showForm === "withdraw" ? "btn-danger" : "btn-secondary"} mx-2`}
            onClick={() => setShowForm("withdraw")}
          >
            Withdraw
          </button>
          <button
            className={`btn ${showForm === "transfer" ? "btn-info" : "btn-secondary"} mx-2`}
            onClick={() => setShowForm("transfer")}
          >
            Interac e-Transfer
          </button>
        </div>

        {showForm === "transfer" && (
          <div className="card p-4 shadow-lg mb-4">
            <h2>Interac e-Transfer</h2>
            <input
              type="text"
              className="form-control my-2"
              placeholder="Recipient Account Number"
              value={transferAccountNumber}
              onChange={(e) => setTransferAccountNumber(e.target.value)}
            />
            <input
              type="email"
              className="form-control my-2"
              placeholder="Recipient Email"
              value={transferEmail}
              onChange={(e) => setTransferEmail(e.target.value)}
            />
            <input
              type="number"
              className="form-control my-2"
              placeholder="Amount"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
            />
            <input
              type="text"
              className="form-control my-2"
              placeholder="Security Question"
              value={transferQuestion}
              onChange={(e) => setTransferQuestion(e.target.value)}
            />
            <input
              type="text"
              className="form-control my-2"
              placeholder="Security Answer"
              value={transferAnswer}
              onChange={(e) => setTransferAnswer(e.target.value)}
            />
            <button
              className="btn btn-success my-2"
              onClick={handleTransfer}
            >
              Send Money
            </button>
            <button
              className="btn btn-danger my-2"
              onClick={handleCancel} // Use the cancel handler
            >
              Cancel
            </button>
            {transferMessage && (
              <div className="alert alert-success mt-2">{transferMessage}</div>
            )}
          </div>
        )}

        {(showForm === "deposit" || showForm === "withdraw") && (
          <div className="card p-4 shadow-lg mb-4">
            <h2>{showForm === "deposit" ? "Deposit" : "Withdraw"}</h2>
            <input
              type="text"
              className="form-control my-2"
              placeholder="Account Number"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
            />
            <input
              type="number"
              className="form-control my-2"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <div className="d-flex justify-content-between mt-3">
              <button
                className={`btn ${showForm === "deposit" ? "btn-success" : "btn-warning"} mx-2`}
                onClick={showForm === "deposit" ? handleDeposit : handleWithdraw}
              >
                {showForm === "deposit" ? "Deposit" : "Withdraw"}
              </button>
              <button
                className="btn btn-secondary mx-2"
                onClick={() => {
                  setAccountNumber("");
                  setAmount("");
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        <h2 className="mt-5 mb-4">Transaction History</h2>
        <table className="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Account Number</th>
              <th>Amount</th>
              <th>Type</th>
              <th>Balance After Transaction</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>
                <td>{transaction.accountNumber}</td>
                <td>${transaction.amount.toFixed(2)}</td>
                <td>{transaction.type}</td>
                <td>{transaction.balanceAfter}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default BankingSystem;
