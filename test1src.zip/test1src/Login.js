// src/Login.js
import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import "./Login.css";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate(); // Initialize useNavigate

  const handleLogin = () => {
    // Simple validation for demonstration
    if (username && password) {
      alert(`Logged in as ${username}`);
      setUsername("");
      setPassword("");
      navigate("/bank"); // Redirect to BankingSystem page
    } else {
      alert("Please enter both username and password.");
    }
  };

  return (
    <div className="login-background">
      <div className="container mt-5">
        <h2 className="text-center mb-4 text-danger">Login</h2>
        <div className="card p-4 shadow-lg login-card">
          <input
            type="text"
            className="form-control my-2 login-input"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            className="form-control my-2 login-input"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <div className="d-flex justify-content-between">
            <button className="btn btn-danger btn-block" onClick={handleLogin}>
              Login
            </button>
            <button className="btn btn-outline-danger btn-block">
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
